<?php
/**
 * ماژول: افزونه‌های فرم‌ساز
 * لایه نازک — رفتار قبلی را حفظ می‌کند؛ فقط مرز ماژول و قابلیت فعال/غیرفعال.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'cgs_module_fb_plugins_enabled' ) ) {
    /**
     * @return bool
     */
    function cgs_module_fb_plugins_enabled() {
        $flags = get_option( 'cgs_module_flags', array() );
        if ( ! is_array( $flags ) ) {
            $flags = array();
        }
        // پیش‌فرض: روشن (تا چیزی نشکند)
        if ( ! array_key_exists( 'fb_plugins', $flags ) ) {
            return true;
        }
        return ! empty( $flags['fb_plugins'] );
    }
}

if ( ! cgs_module_fb_plugins_enabled() ) {
    return;
}


// کلاس هسته از قبل توسط autoload / CGS_Modules بارگذاری می‌شود.
// این فایل فقط مرز ماژول و پرچم فعال‌سازی را تعریف می‌کند.
if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
    // error_log( '[CGS] module fb_plugins ready' );
}

